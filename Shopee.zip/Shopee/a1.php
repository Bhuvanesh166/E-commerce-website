<?php

echo $_POST["name"];
echo $_POST["email"];
echo $_POST["password"];
?>
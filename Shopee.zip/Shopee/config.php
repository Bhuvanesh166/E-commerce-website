<?php

$conn = mysqli_connect('localhost','root','','productdb') or die('connection failed');

?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
echo "Welcome to school";
$color="blue";
echo "My car is".$color."<br>";
echo "My dress is".$COLOR."<br>";
echo "My box is".$coLOR."<br>";
?>
</body>
</html>